<html>
<head>
	<title>Ninja_Gold</title>
</head>
<body>

<p>Directory access is forbidden.</p>

</body>
</html>