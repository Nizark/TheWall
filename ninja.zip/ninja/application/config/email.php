<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['protocol']  = "";
$config['smtp_host'] = "";
$config['smtp_user'] = "";
$config['smtp_pass'] = "";
$config['smtp_port'] = "";

//end of email.php